﻿using System.Net;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using TrainingManagement.Data;
using TrainingManagement.Models;

namespace TrainingManagement.Controllers;

[ApiController]
[Route("[controller]")]
public class HRController : ControllerBase
{
    private readonly ApiDbContext _context;

    public HRController(ApiDbContext context)
    {
        _context = context;
    }

    [HttpGet]
    [Route("get-all-users")]
    public async Task<IActionResult> Get()
    {
        try
        {
            var users = await _context.User.Where(b => b.user_type != "HR").ToListAsync();
            if (users.Count == 0)
            {
                throw new BadHttpRequestException("There are no users to get!");
            }
            
            return Ok(users);
        }
        catch (BadHttpRequestException error)
        {
            return BadRequest(error.Message);
        }

    }

    [HttpPatch]
    [Route("edit-user")]
    public async Task<IActionResult> EditUserByIdAsync(User user)
    {
        try
        {
            byte[] encodedPasswordBytes = System.Text.Encoding.Unicode.GetBytes(user.password);
            user.password = System.Convert.ToBase64String(encodedPasswordBytes);

            _context.User.Update(user);
            await _context.SaveChangesAsync();

            return NoContent();
        }
        catch (BadHttpRequestException error) {
            return BadRequest(error.Message);
        }
    }
}

