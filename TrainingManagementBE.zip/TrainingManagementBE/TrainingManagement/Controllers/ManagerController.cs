﻿using System.Net;
using System.Net.Mail;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using TrainingManagement.Data;
using TrainingManagement.Models;

namespace TrainingManagement.Controllers;

[ApiController]
[Route("[controller]")]
public class ManagerController : ControllerBase
{
    private readonly ApiDbContext _context;

    public ManagerController(ApiDbContext context)
    {
        _context = context;
    }


    [HttpGet]
    [Route("get-my-users-applications")]
    public async Task<IActionResult> GetApplications(int manager_id)
    {
        try
        {
            var myUsersIds = new List<int>();
            var myUsers = await _context.User.Where(b => b.manager_id == manager_id).ToListAsync();
            foreach (var i in myUsers)
            {
                myUsersIds.Add(i.Id);
            }

            var allApplications = await _context.Training_Application.Where(b => myUsersIds.Contains(b.user_id)).ToListAsync();

            foreach (var i in allApplications)
            {
                i.training = _context.Training.Where(b => b.Id == i.training_id).Single();
            }

            return Ok(allApplications);
        }
        catch (BadHttpRequestException error)
        {
            return BadRequest(error.Message);
        }
    }

    [HttpGet]
    [Route("get-my-users")]
    public async Task<IActionResult> GetMyUsers(int manager_id)
    {
        try
        {
            var user = await _context.User.Where(b =>b.user_type == "Employee" && (b.manager_id == manager_id || b.manager_id == null)).ToListAsync();

            if (user.Count == 0)
            {
                throw new BadHttpRequestException("No users to get!");
            }

            return Ok(user);
        }
        catch (BadHttpRequestException error)
        {
            return BadRequest(error.Message);
        }

    }

    [HttpPatch]
    [Route("assign-user-to-manager")]
    public async Task<IActionResult> AssignUserToManager(int manager_id, int user_id)
    {
        try
        {
            var user = await _context.User.FindAsync(user_id);

            if (user == null)
            {
                throw new BadHttpRequestException("There are no user with this id");
            }

            if (user.user_type != "Employee")
            {
                throw new BadHttpRequestException("You can't assign a manager to this user_type!");
            }
            user.manager_id = manager_id;

            _context.User.Update(user);
            await _context.SaveChangesAsync();

            return Ok(user);
        }
        catch (BadHttpRequestException error)
        {
            return BadRequest(error.Message);
        }

    }

    public record SetResponseDTO (int application_id, string state, string feedback);

    [HttpPatch]
    [Route("set-application-response")]
    public async Task<IActionResult> SetApplicationResponse([FromBody] SetResponseDTO data)
    {
        try
        {
            var application = await _context.Training_Application.FindAsync(data.application_id);
            if (application == null)
            {
                throw new BadHttpRequestException("Application doesn't exist!");
            }
            application.state = data.state;
            application.response = data.feedback;

            _context.Training_Application.Update(application);
            await _context.SaveChangesAsync();

            return Ok(application);
        }
        catch (BadHttpRequestException error)
        {
            return BadRequest(error.Message);
        }

    }
}

