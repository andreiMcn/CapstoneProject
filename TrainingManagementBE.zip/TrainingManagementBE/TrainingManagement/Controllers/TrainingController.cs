﻿using System;
using System.Net;
using System.Net.Mail;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using TrainingManagement.Data;
using TrainingManagement.Models;

namespace TrainingManagement.Controllers;

[ApiController]
[Route("[controller]")]
public class TrainingsController : ControllerBase
{
    private readonly ILogger<TrainingsController> _logger;
    private readonly ApiDbContext _context;

    public TrainingsController(ILogger<TrainingsController> logger, ApiDbContext context)
    {
        _context = context;
        _logger = logger;
    }

    [HttpGet]
    [Route("get-all-trainings")]
    public async Task<IActionResult> Get()
    {
        var allTrainings = await _context.Training.ToListAsync();

        return Ok(allTrainings);
    }

    [HttpGet]
    [Route("get-training-by-id")]
    public async Task<IActionResult> GetUserByIdAsync(int id)
    {
        var training = await _context.Training.FindAsync(id);
        if (training == null)
        {
            return NotFound();
        }

        return Ok(training);
    }

    [HttpPost]
    public async Task<IActionResult> PostAsync(Training training)
    {
        try
        {
            _context.Training.Add(training);
            await _context.SaveChangesAsync();
            return Created($"/get-training-by-id?id={training.Id}", training);
        }
        catch (BadHttpRequestException error)
        {
            return BadRequest(error.Message);
        }
    }

    [HttpPatch]
    [Route("edit-training")]
    public async Task<IActionResult> EditTrainingByIdAsync(Training training)
    {
        try
        {
            _context.Training.Update(training);
            await _context.SaveChangesAsync();

            return NoContent();
        }
        catch (BadHttpRequestException error)
        {
            return BadRequest(error.Message);
        }
    }

    [HttpGet]
    [Route("get-training-with-application")]
    public async Task<IActionResult> GetTrainingsForUser(int id)
    {
        try
        {
            var allTrainings = await _context.Training.ToListAsync();

            foreach (var i in allTrainings)
            {
                i.Training_application = await _context.Training_Application.Where(b => b.training_id == i.Id && b.user_id == id).ToListAsync();
            }
            
            return Ok(allTrainings);
        }
        catch (BadHttpRequestException error)
        {
            return BadRequest(error.Message);
        }
    }

}

