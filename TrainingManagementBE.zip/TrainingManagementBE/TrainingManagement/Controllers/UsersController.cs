﻿using System;
using System.Net;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using TrainingManagement.Data;
using TrainingManagement.Models;

namespace TrainingManagement.Controllers;

[ApiController]
[Route("[controller]")]
public class UsersController : ControllerBase
{

    private readonly ILogger<UsersController> _logger;

    private readonly ApiDbContext _context;

    public UsersController(ILogger<UsersController> logger, ApiDbContext context)
    {
        _logger = logger;
        _context = context;
    }

    [HttpGet]
    [Route("get-all-users")]
    public async Task<IActionResult> Get()
    {
        var allUsers = await _context.User.ToListAsync();

        return Ok(allUsers);
    }

    [HttpGet]
    [Route("get-user-by-id")]
    public async Task<IActionResult> GetUserByIdAsync(int id)
    {
        var user = await _context.User.FindAsync(id);
        if (user == null)
        {
            return NotFound();
        }

        return Ok(user);
    }

    [HttpGet]
    [Route("Login")]
    public async Task<IActionResult> GetUser(string email_address, string password)
    {
        try
        {
            byte[] encodedPasswordBytes = System.Text.Encoding.Unicode.GetBytes(password);
            password = System.Convert.ToBase64String(encodedPasswordBytes);

            var user = await _context.User.Where(b => b.email_address == email_address && b.password == password).ToListAsync();
           
            if (user.Count == 0)
            {
                throw new BadHttpRequestException("Incorrect email address or password!");
            }

            if (user[0].is_deleted == true)
            {
                throw new BadHttpRequestException("Account is deactivated, contact a HR!");
            }

            return Ok(user[0]);
        }
        catch (BadHttpRequestException error)
        {
            return BadRequest(error.Message);
        }

    }

    [HttpPost]
    public async Task<IActionResult> PostAsync(User user)
    {
        try
        {
            var isUserFound = _context.User.Where(b => b.email_address == user.email_address).ToArray();

            if (isUserFound.Length > 0) {
                throw new BadHttpRequestException("An account with this email address already exists!");
            }

            byte[] encodedPasswordBytes = System.Text.Encoding.Unicode.GetBytes(user.password);
            user.password = System.Convert.ToBase64String(encodedPasswordBytes);

            _context.User.Add(user);
            await _context.SaveChangesAsync();
            return Created($"/get-user-by-id?id={user.Id}", user);
        }
        catch (BadHttpRequestException error) {
            return BadRequest(error.Message);
        }
    }

    [HttpGet]
    [Route("get-all-trainings")]
    public async Task<IActionResult> GetAllTrainings()
    {
        var allTrainings = await _context.Training.ToListAsync();

        return Ok(allTrainings);
    }

    [HttpPost]
    [Route("apply-for-training")]
    public async Task<IActionResult> PostApplyForTrainingAsync(Training_Application training_application)
    {
        try
        {
            _context.Training_Application.Add(training_application);
            await _context.SaveChangesAsync();
            return Ok(training_application);
        }
        catch (BadHttpRequestException error)
        {
            return BadRequest(error.Message);
        }
    }

    [HttpDelete]
    [Route("cancel-training-application")]
    public async Task<IActionResult> CancelTrainingApplication(int training_id)
    {
        try
        {
            var test = await _context.Training_Application.Where(c => c.Id == training_id).ExecuteDeleteAsync();

            return Ok(test);
        }
        catch (BadHttpRequestException error)
        {
            return BadRequest(error.Message);
        }

    }

}

