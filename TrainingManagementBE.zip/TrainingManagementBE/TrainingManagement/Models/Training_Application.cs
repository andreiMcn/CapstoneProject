﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace TrainingManagement.Models
{
    public class Training_Application
    {
        public int Id { get; set; }
        public string state { get; set; } = null!;
        public string? response { get; set; }
        public string? feedback { get; set; }
        public int training_id { get; set; }
        public int user_id { get; set; }

        [ForeignKey("user_id")]
        public User? user { get; set; }

        [ForeignKey("training_id")]
        public Training? training { get; set; }
    }
}

