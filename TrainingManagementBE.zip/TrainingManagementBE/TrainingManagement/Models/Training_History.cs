﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace TrainingManagement.Models
{
    public class Training_History
    {
        public int Id { get; set; }
        public User? user { get; set; }
        public Training? training { get; set; }
        public string? feedback { get; set; }
    }
}

