﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace TrainingManagement.Models
{
    public class Training
    {
        public int Id { get; set; }
        public string name { get; set; } = null!;
        public string description { get; set; } = null!;
        public DateTime start_date { get; set; }
        public DateTime end_date { get; set; }

        [ForeignKey("added_by")]
        public int added_by { get; set; }

        public ICollection<Training_Application>? Training_application { get; set; }
    }
}

