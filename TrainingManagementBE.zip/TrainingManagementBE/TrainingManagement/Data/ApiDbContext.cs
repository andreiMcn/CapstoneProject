﻿using System;
using Microsoft.EntityFrameworkCore;
using TrainingManagement.Models;

namespace TrainingManagement.Data
{
	public class ApiDbContext: DbContext
	{
        protected readonly IConfiguration Configuration;

        protected override void OnModelCreating(ModelBuilder builder)
        {
            builder.Entity<User>()
                .HasIndex(u => u.email_address)
                .IsUnique();
        }


        public ApiDbContext(IConfiguration configuration)
        {
            Configuration = configuration;
        }

        protected override void OnConfiguring(DbContextOptionsBuilder options)
        {
            // connect to postgres with connection string from app settings
            options.UseNpgsql(Configuration.GetConnectionString("DefaultConnection"));
        }


        public DbSet<User> User { get; set; }
        public DbSet<Training> Training { get; set; }
        public DbSet<Training_Application> Training_Application { get; set; }


    }
}

